import nltk
nltk.download('omw-1.4')