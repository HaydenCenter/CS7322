## HOW TO RUN
### Run Following Commands from bash

pip install spacy
pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.0.0/en_core_web_sm-3.0.0.tar.gz

pip install pattern
sudo apt install default-libmysqlclient-dev

pip install nltk

python installs.py
python QuestionGenerator.py