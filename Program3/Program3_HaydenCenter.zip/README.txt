## HOW TO RUN
## Run Following Commands from bash

pip install numpy
pip install pip setuptools wheel
pip install spacy
pip install https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.0.0/en_core_web_sm-3.0.0.tar.gz

sudo apt install default-libmysqlclient-dev
pip install pattern

pip install nltk

python installs.py
python QuestionGenerator.py
